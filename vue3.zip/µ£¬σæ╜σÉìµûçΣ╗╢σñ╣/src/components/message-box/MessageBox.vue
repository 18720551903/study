<template>
  <div class="message-box">
    消息盒子
  </div>
</template>

<style lang="scss" scoped>
.message-box {
  width: 250px;
  height: 100px;
  margin-top: 24px;
  background-color: #fff;
  border-radius: 4px;
  box-shadow: 0 1px 6px rgba(0, 0, 0, 0.2);
}
</style>

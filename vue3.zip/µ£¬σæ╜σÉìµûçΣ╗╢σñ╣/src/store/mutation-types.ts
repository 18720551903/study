export const SET_MENUS = 'set-menus';
